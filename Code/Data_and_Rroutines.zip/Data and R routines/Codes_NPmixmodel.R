###################### ###################### ###################### ###################### ###################### ######################
                            # The following is R routine to implement the procedures in "Estimation of a Two-component Mixture Model"
###################### ###################### ###################### ###################### ###################### ######################



# Distribution of the known component. Note that we can always transform the data so that Fb is Uniform(0,1).
# Fb is a function that takes input a vector and evaluates Fb (or an estimate of it) at the input values
Fb <- function(eval.points){
  ## Calculate the known F_b at the data points
  ## Usually would need to CHANGE this
  ## Note: for Uniform(0,1) F_b(x) = x
  return(eval.points) 
  ## In case of the example in Section 9.2 of the paper, we use the empirical CDF of the data in "Backgroundstars_RV.txt" to estimate Fb.data.
}

library(Iso)
library(fdrtool)
# This function calculates the distance $\gamma  \ d_n(\hat{F}_{s,n}^{\gamma},\check{F}_{s,n}^\gamma)$ for grid of gamma values in [0,1].
# data is a numeric vector containing observations from the mixture model.
# Bigger gridsize  gives more  accurate estimates of alpha.
EstMixMdl <- function(data,Fb,gridsize=200)
{
  n <- length(data)    		 			 ## Length of the data set
  data <- sort(data)       ## Sorts the data set
  data.1 <- unique(data)	 	## Finds the unique data points
  Fn <- ecdf(data)			        ## Computes the empirical DF of the data
  Fn.1 <- Fn(data.1)		      ## Empirical DF of the data at the data points
  Fb.data <- Fb(data.1)       ## evaluating Fb at the the unique data points
  ## Compute the weights (= frequency/n) of the unique data values, i.e., dF_n
  Freq <- diff(c(0,Fn.1))
  distance <- rep(0,gridsize)
  distance[0]<- sqrt(t((Fn.1-Fb.data)^2)%*%Freq)
  for(i in 1:gridsize)
  {
  		 a <- i/gridsize               ## Assumes a value of the mixing proportion
    F.hat <- (Fn.1-(1-a)*Fb.data)/a			    ## Computes the naive estimator of F_s
    F.is <- pava(F.hat,Freq,decreasing=FALSE)	## Computes the Isotonic Estimator of F_s
    F.is[which(F.is<=0)] <- 0
    F.is[which(F.is>=1)] <- 1
    distance[i] <- a*sqrt(t((F.hat-F.is)^2)%*%Freq);
  }
  return(distance)
}
# The following function evaluates the numerical second derivative of any function
Comp_2ndDer <- function(dist.alpha, gridsize)
  {
  dder <- diff(dist.alpha)    ## Computes the 1st order differences
  dder <- diff(dder)      ## Computes the 2nd order differences 
  dder <- c(0,0,dder)       ## The numerical double derivative vector
  
  return(dder)
}


# The following set of commands will give a plot of $\gamma  \ d_n(\hat{F}_{s,n}^{\gamma},\check{F}_{s,n}^\gamma)$ for $\gamma \in [0,1].$

dist.alpha <- EstMixMdl(data,Fb,gridsize)
frame()
plot((1:gridsize)/gridsize,dist.alpha,type="l",xlab="x",ylab="Distance",col="blue")
###################### ###################### ###################### ###################### ###################### ######################
                            # LOWER CONFIDENCE INTERVAL
###################### ###################### ###################### ###################### ###################### ######################

# Lower.Cfd.Bound denotes lower confidence bound
q <- 0.6792 # The 95% quantile, other values can be easily evaluated by simple monte-carlo procedure
n <- length(data) ## Length of the data set
Lower.Cfd.Bound <- sum(dist.alpha>q/sqrt(n))/gridsize

###################### ###################### ###################### ###################### ###################### ######################
                          # Estimate of Alpha
###################### ###################### ###################### ###################### ###################### ######################
#Now to find the Estimate
#Here we have taken the choice of c_n to be 0.1* log(log(n)).
c.n<-0.1* log(log(n))
Est<- sum(dist.alpha>c.n/sqrt(n))/gridsize
# Code for the cross validated choice of c_n is forthcoming. (check http://stat.columbia.edu/~rohit  for updates)

###################### ###################### ###################### ###################### ###################### ######################
                          # Heuristic Estimate of Alpha based on the second derivative
###################### ###################### ###################### ###################### ###################### ######################

#To find an heuristic estimator of ${\alpha}_0$ as discussed in \citet[Section 4.3]{PatraSen13}, use the following lines of code.
# Numerically find the 2nd derivative of `dist.alpha'

dder <- Comp_2ndDer(dist.alpha, gridsize)
Est <- which.max(dder)/gridsize

## Overlaid plot of the normalized 2nd derivative
lines((1:gridsize)/gridsize ,dder*(max(dist.alpha)/max(dder)),col='red')
legend("topright",c("Distance","Scaled 2nd derivative"),
lty=c(1,1), col = c("blue","red") )

###################### ###################### ###################### ###################### ###################### ######################
                         #Replicating the results in the paper
###################### ###################### ###################### ###################### ###################### ######################

## functions  EstMixMdl and Comp_2ndDer at the beginning of this file need to be sourced first 

###################### ###################### ###################### ###################### ###################### ######################
                         #Example in Section 9.1
###################### ###################### ###################### ###################### ###################### ######################
library(Iso)
library(fdrtool)
data = read.table('prostatedatazvalues.txt');
temp=pnorm(data$V1);
temp2=qt(temp,100);
pvalues=2*pt(abs(temp2),100)-1;
n <- length(pvalues) ## Length of the data set
Fb <- function(eval.points){
  return(eval.points) 
}
gridsize<-4000
dist.alpha <- EstMixMdl(pvalues,Fb,gridsize)

q <- 0.6792 # The 95% quantile, other values can be easily evaluated by simple monte-carlo procedure
Lower.Cfd.Bound <- sum(dist.alpha>q/sqrt(n))/gridsize
print(paste(" 95% lower confidence bound  of alpha_0 is ", Lower.Cfd.Bound))

##Estimate with the choice of c_n = 0.1* log(log(n)).
c.n<-0.1*log(log(n))
Est<- sum(dist.alpha>c.n/sqrt(n))/gridsize
print(paste("Estimator of alpha_0 when c_n=.1*log(log(n)) is ", Est))
## heuristic estimator of ${\alpha}_0$
dder <- Comp_2ndDer(dist.alpha, gridsize)
h.Est <- which.max(dder)/gridsize
print(paste("Heuristic estimator of alpha_0 is ", h.Est))

## the diagnostic plot 
frame()
plot((1:gridsize)/gridsize,dist.alpha,type="l",xlab="x",ylab="Distance",col="blue")
lines((1:gridsize)/gridsize ,dder*(max(dist.alpha)/max(dder)),col='red')
legend("topright",c("Distance","Scaled 2nd derivative"),
lty=c(1,1), col = c("blue","red") )

###################### ###################### ###################### ###################### ###################### ######################
                         #Example in Section 9.2
###################### ###################### ###################### ###################### ###################### ######################
library(Iso)
library(fdrtool)
data = read.table('carina.dat')
x = data[data$V8 + data$V9> 0,]
x = x[x$V6 < 3,]
data = x$V4; # represents the Radial velocity data of stars in the  Carina galaxy
gridsize<-4000 #recommended grid size (The bigger the better)
n <- length(data)
Fb <- function(eval.points){
  data.2 <- read.table('Backgroundstars_RV.txt')
  Fb <- ecdf(data.2$V1)
  return(Fb(eval.points)) 
}

dist.alpha <- EstMixMdl(data,Fb,gridsize)
q <- 0.6792 # The 95% quantile, other values can be easily evaluated by simple Monte Carlo procedure
Lower.Cfd.Bound <- sum(dist.alpha>q/sqrt(n))/gridsize
print(paste(" 95% lower confidence bound  of alpha_0 is ", Lower.Cfd.Bound))

##Estimate with the choice of c_n = 0.1* log(log(n)).
c.n<-0.1*log(log(n))
Est<- sum(dist.alpha>c.n/sqrt(n))/gridsize
print(paste("Estimator of alpha_0 when c_n=.1*log(log(n)) is ", Est))
## heuristic estimator of ${\alpha}_0$
dder <- Comp_2ndDer(dist.alpha, gridsize)
h.Est <- which.max(dder)/gridsize
print(paste("Heuristic estimator of alpha_0 is ", h.Est))

## the diagnostic plot 
frame()
plot((1:gridsize)/gridsize,dist.alpha,type="l",xlab="x",ylab="Distance",col="blue")
lines((1:gridsize)/gridsize ,dder*(max(dist.alpha)/max(dder)),col='red')
legend("topright",c("Distance","Scaled 2nd derivative"),
lty=c(1,1), col = c("blue","red") )

###################### ###################### ###################### ###################### ###################### ######################
   # For  a R routine for choosing c_n through Cross validation as well as a more extensive documentation of the codes used in the paper
                                      ##  see  http://stat.columbia.edu/~rohit
###################### ###################### ###################### ###################### ###################### ######################