Title: Estimation of a Two-component Mixture Model]{Estimation of a Two-component Mixture Model with Applications to Multiple Testing
Authors:
Rohit Kumar Patra, Department of Statistics, Columbia University, 1255 Amsterdam Ave, New York, NY, 10027, 718-679-5522, rohit@stat.columbia.edu,  http://stat.columbia.edu/~rohit/

Bodhisattva Sen, Department of Statistics, Columbia University, 1255 Amsterdam Avenue, Room # 1032, New York, NY 10027, 212-851-2149, bodhi@stat.columbia.edu, http://stat.columbia.edu/~bodhi

In the following, we give a brief description of the data sets used in Section 9 of the paper.

Prostate Data (Section 9.1 of the paper): The file "prostatedatazvalues.txt" contains 6033 Z-values used in Section 9.1 of the paper. We can either use this data or convert it to p-values. If we use z-values then the  distribution of the known component can be set to be the standard Gaussian distribution. If we use the p-values then the distribution of the known component can be set to be the uniform distribution on (0,1). In the paper and the attached R routine, we use the p-values. The data set was borrowed from Chapter 2 of Bradley Efron's book “Large-scale Inference”. The data set can also be found at http://statweb.stanford.edu/~ckirby/brad/LSI/datasets-and-programs/data/leukz.RData.


Carina Data (Section 9.2 of the paper): The file "carina.dat" contains the radial (line of sight) velocities (RV) of n = 1266 stars Carina, a dwarf spheroidal (dSph) galaxy  contaminated with Milky Way stars in the field of view. We also have the RV data for 170601 stars in the Milky way. We use the RV's of the Milky way stars to get an very good estimate of the distribution of the known component. These RV values can be found be in file named "Backgroundstars_RV.txt".

The following lines of R code extract the radial velocity of stars in the Milky way from the 'carina.dat' file.

#######
data = read.table('carina.dat')
x = data[data$V8 + data$V9> 0,]
x = x[x$V6 < 3,]
data = x$V4; # represents the Radial velocity data of stars in the  Carina galaxy
######

The R (CRAN) routine to implement the procedures developed in the paper as well as the codes to replicate the results in Sections 9.1 and 9.2 can be found in the file named "Codes_NPmixmodel.R".

For more details see http://stat.columbia.edu/~rohit/.
