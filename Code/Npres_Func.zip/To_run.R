
library(mvtnorm)
source("Functions_needed.R")
## These codes work only in the case X and Y are are real random variables and not vector valued.
n=50 # Sample size
sigma_alt=0 # Used for generating the random variables (see Section 4 (simulation section)).
z.dim=1 # Dimension of z

##############################################################################
## data generated as in the paper data.to.work is a matrix with nrow=n and ncol=dim+2 with (x, y, z_1, ...z_dim) as columns
##############################################################################
data.to.work<- data.gen(n,sigma_alt,z.dim)
#Evaluate the statistic
statistics<-npresid.statistics(data.to.work,z.dim)
##############################################################################
# bootstrap calculations to get p-values
##############################################################################
# R is no of bootstrap replications neeeded

# accuracy: It determines how precise you want to be when inverting the estimated conditional distribution function while generating the bootstrap samples.  500 is generally more than sufficient

out<-npresid.boot(data.to.work,z.dim,accuracy=500,R=50)
# R=1000  can take a really long time

print(out$boot.data)

pvalue.out=out$p.value





