# main function

##-----------------------------------------------------------------------------------
##			A function to estimate alp and F.s given a data vector
#  Input:
# 1. "data", a vector.
# 2.  "method": (a) "fixed" : it will compute the estmate based on the value of 'c.n' 
# 			  (b) "cv" : use cross-validation for choosing 'c.n' (tuning parameter)
# 3. 'c.n': a postive number, defualt value is '.1 log(log(n)', where 'n' is the length of the vector.
# 4. 'folds': Number of folds used for cross-validation, defualt is 10.
# 5. 'reps': Number of replications for cross-validation, defualt is 1.
# 6. 'cn.s': sequence of 'c.n' to be used for cross-validation, a vector of values. defualt is eqaully spaced grid of 100 vlaues between '.001 * log(log(n))' to '.2* log(log(n))'.
# 7. 'cn.length': number of eqaully spaced tuning parameter (between '.001 * log(log(n))' and '.2* log(log(n))') values to search from, defualt is 100.
# 8. 'gridsize': Number of eqaully spaced points (between 0 and 1) to evaluate the distance function. Larger values are more computationally intensive but also lead to more accurate estimates. Defualt is 600.


# Output: A list with the follwoing elements
# 1. 'alp.hat' : estimate of alpha
# 2. 'Fs.hat': A list containing wth elements 'x' and 'y' values for the function estimate of 'F.s'
# 3. 'dist.out': An object of the class 'dist.fun' using the complete data.gen
# 4. 'c.n' : Value of the tuning parameter used to compute the final estimate.
# 4. 'cv.out': An object of class 'cv.mixmodel'. The object is NULL if method is "fixed".

##-----------------------------------------------------------------------------------

est.mix.model <-function(data, method=c("lwr.bnd", "fixed", "cv"),   c.n = NULL, folds =10, reps = 1, cn.s =NULL, cn.length =100, gridsize= 600){
	if(!is.vector(data)) stop(" 'data' has to be a vector.")

	n<- length(data)
	if(is.null(method)){
		stop("'method' can not be NULL")
	}
	if(method == 'lwr.bnd'){
		dist.out <- dist.calc(data, gridsize = gridsize)
		q<- 0.6792
		alp.Lwr <- sum(dist.out$distance > q/ sqrt(n))/gridsize
		alp.hat <- NULL
		Fs.hat.fun <- NULL
		c.n <- NULL
	} else{
		alp.Lwr<- NULL
	}
	if(method == "fixed"){
		if(is.null(c.n)){
			warning("'c.n' is not given. Fixing it to be '0.1*log(log(n))")
			c.n <- 0.1 *log(log(n))
		}
		dist.out <- dist.calc(data, gridsize = gridsize)
		alp.hat <- sum(dist.out$distance > c.n/ sqrt(n))/gridsize
		if(alp.hat >0){
			F.hat <- (dist.out$F.n-(1-alp.hat)*dist.out$F.b)/alp.hat ## Computes the naive estimator of F_s
			Fs.hat=pava(F.hat,dist.out$Freq,decreasing=FALSE) ## Computes the Isotonic Estimator of F_s
			Fs.hat[which(Fs.hat<=0)]=0
			Fs.hat[which(Fs.hat>=1)]=1
		} else {
			Fs.hat = dist.out$F.b
		}

		Fs.hat.fun<- NULL
		Fs.hat.fun$y = Fs.hat
		Fs.hat.fun$x =  dist.out$F.n.x
	} else if(method == "cv"){
		out.cv <- cv.mixmodel(data, folds = folds, reps = reps, cn.s = cn.s, cn.length =cn.length , gridsize = gridsize)
		alp.hat <- out.cv$alp.hat
		Fs.hat.fun <- out.cv$Fs.hat
		dist.out <- out.cv$dist.out
		c.n <- out.cv$cn.cv
	}

	ret <- list(alp.hat = alp.hat,
				Fs.hat = Fs.hat.fun,
				dist.out = dist.out,
				c.n = c.n,
				alp.Lwr =alp.Lwr,
				n = n)
	if(method == "cv"){
		ret$cv.out <-  out.cv
	} else{
		ret$cv.out <- NULL
	}
	ret$method = method
	ret$call <- match.call()

	class(ret) <- "mixmodel"
	return(ret)
}
print.mixmodel <- function(x, ...){
	cat("Call:")
	print(x$call)
	if(x$method != "lwr.bnd"){
		print(paste("Estimate of alp is" , x$alp.hat))
		print(paste(" The chosen value c_n is", x$c.n))
		if( !is.null(x$cv.out)){
			par(mfrow=c(1,2))
			plot(x$cv.out)
		}
		plot(x$dist.out)
	} else if(x$method == 'lwr.bnd'){
		plot(x$dist.out)
		print (paste("The  '95%' lower confidence for alp_0 is ", x$alp.Lwr))
	}
}
plot.mixmodel <- function(x, ...){
	if(x$method != "lwr.bnd"){
		plot(x$dist.out)
		abline(h= {x$c.n /sqrt(x$n)}, col="red", lwd= 1.3)
		abline(v= x$alp.hat, lty=2, lwd =1, col="black")
	} else {
		plot(x$dist.out)
		abline(h = 0.6792/sqrt(x$n), col="red", lwd= 1.3)
		abline(v= x$alp.Lwr, lty=2, lwd =1, col="black")
	}
}

