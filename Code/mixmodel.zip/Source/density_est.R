
##-----------------------------------------------------------------------------------
##			A function to compute the estimate of f.s (the density corresponding to F.s) when f.s is known to be either decreasing or increasing.
##-----------------------------------------------------------------------------------


density.mix.model<- function(input, dec.density =TRUE){
	if(class(input) == "cv.mixmodel" || class(input) == "mixmodel"){
		Fs.hat <-  input$Fs.hat
	} else {
			stop("This function only works on objects of class 'cv.mixmodel' or 'mixmodel'. See functions 'est.mix.model' or 'cv.mixmodel'.")
	}
	if(dec.density== TRUE){
		ll <- gcmlcm(Fs.hat$x,Fs.hat$y, type="lcm")
	} else if(dec.density== FALSE){
		ll <- gcmlcm(Fs.hat$x,Fs.hat$y, type="gcm")
	}
	fs.hat <- NULL
	fs.hat$x=rep(ll$x.knots,each=2) #data points for density
	fs.hat$y=c(0,rep(ll$slope.knots,each=2),0) #value of density
	return(fs.hat)
}



