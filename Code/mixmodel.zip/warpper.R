
##-----------------------------------------------------------------------------------
##			For all the function here we have assumed that F_b is Unif(0,1)
##-----------------------------------------------------------------------------------

rm(list=ls())
source("Source/density_est.R")
source("Source/dist_calc.R")
source("Source/est_mix_model.R")
source("Source/cv_mixmodel.R")

##-----------------------------------------------------------------------------------
##			A function to generate data vector of size 'n' from
					# F = alp x Beta(1,5) + (1-alp) Unif(0,1)
		# The follwoing function returns a vector of length n
##-----------------------------------------------------------------------------------


data.gen<- function( n, alpha){
	ind<- rbinom(n, 1, alpha)
	data<- ind* rbeta(n, 1,5) + (1-ind)* runif(n,0,1)
	return(data)
}
data.1<- data.gen(n = 1000, alp = .2)

# Computing the 95%  confidence lower bound for alpha_0

est.lwr.bnd <- est.mix.model(data.1, method = "lwr.bnd", gridsize = 600)
plot(est.lwr.bnd)

# Estmating alp using the default value of 'c,n'
est.default <- est.mix.model(data.1, method = "fixed", gridsize = 600)
print(est.default)
plot(est.default)

# Estmating alp using a particular choice of c.n
est.fixed <- est.mix.model(data.1, method = "fixed", c.n = .05*log(log(length(data.1))), gridsize = 600)
print(est.fixed)
plot(est.fixed)

# Estmating alp using cross-validated choice of 'c.n' and defualt choice of the rest of parameters.
est.cv <- est.mix.model(data.1, method = "cv", gridsize = 600)
print(est.cv)
plot(est.cv)

out <-density.mix.model(est.cv)
plot(est.cv$Fs.hat, type= "l", xlab= "x", ylab= "F_s")
plot(out, type="l", xlab="x", ylab= "f_s")


